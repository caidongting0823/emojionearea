# Emojione utility for Swift


### How to use

This utility provides a method to convert from shortname to unicode characters.

### How to re-generate mapping

```
cd lib/swift/generator
npm install
node generate.js
```
